# Ailem Yanımda — v0.2.2

Aynı APK iki telefonda kullanılır. Bu sürüm yalnızca **kamera, sesli iletişim ve bağlantı durumu** için tasarlanmıştır.

## v0.2.2 değişiklikleri

- Konum, harita, konum geçmişi, SOS ve pil yüzdesi kaldırılmış halde kalır.
- Kamera aktarımı **akıcılık öncelikli** hale getirildi: hedef görüntü 320×240 ve JPEG kalitesi 22.
- Kamera artık tek tek ağır fotoğraf çekmek yerine sürekli preview akışı üretir. Firebase yavaşlarsa eski kareler kuyrukta birikmez; en yeni kare tercih edilir.
- Kontrol telefonunda JPEG çözme/döndürme işlemi arka planda yapılır. Dekoder yetişemezse eski kare atılır; arayüzün donması azaltılır.
- Uzak kamera 1.0×–4.0× dijital zoom özelliği korunur.
- Ses sistemi iyi çalışan eski yönteme geri döndürüldü: 8 kHz G.711 µ-law, yaklaşık 150 ms ses parçaları ve tek güncel ses paketi.
- Konuşma düğmesine basıldığında mikrofon Firebase sunucu onayını beklemeden hemen başlar.
- Bağlantı göstergesi, sade arayüz, logo ve kırmızı/yeşil kamera-dinleme düğmeleri korunur.
- Kamera/mikrofon kullanımı gizli değildir; kamera telefonunda görünür foreground bildirimi devam eder.

## İzinler

Kamera telefonunda **Kamera**, **Mikrofon** ve Android 13+ için **Bildirim** izni gerekir. Kontrol telefonunda yalnızca karşı tarafa konuşmak için mikrofon izni gerekir.

Konum izni istenmez ve AndroidManifest'te bulunmaz.

## Firebase

Firebase Authentication > Anonymous etkin olmalıdır. Realtime Database kuralları için `firebase_database_rules.json` kullanılabilir.

Paket adı: `com.ailemyanimda.app`

Firebase istemci bilgileri `FirebaseProvider.java` içinde mevcut projeye gömülüdür.

## GitHub Actions ile APK oluşturma

Projeyi GitHub'a yükleyip Actions sekmesindeki **Build Android APK** iş akışını çalıştırın. İş akışı debug APK’yı `AilemYanimda-v0.2.2-debug-apk` artifact’i olarak üretir.
