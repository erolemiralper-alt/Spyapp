package com.ailemyanimda.app;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppPrefs {
    private static final String NAME = "ailem_yanimda";
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }

    public static String get(Context c, String k) { return p(c).getString(k, ""); }
    public static void put(Context c, String k, String v) { p(c).edit().putString(k, v).commit(); }
    public static void clearRole(Context c) {
        p(c).edit().remove("role").remove("family_secret").commit();
    }
    public static String role(Context c) { return get(c,"role"); }
    public static String secret(Context c) { return get(c,"family_secret"); }
}
