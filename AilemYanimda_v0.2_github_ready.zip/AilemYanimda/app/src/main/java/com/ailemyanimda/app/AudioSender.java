package com.ailemyanimda.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Base64;
import androidx.core.content.ContextCompat;
import com.google.firebase.database.DatabaseReference;
import java.util.HashMap;
import java.util.Map;

public class AudioSender {
    public static final int SAMPLE_RATE = 8000;
    private static final int SAMPLES_PER_CHUNK = 1600; // ~200 ms

    private final Context context;
    private final DatabaseReference ref;
    private volatile boolean running = false;
    private volatile boolean uploading = false;
    private Thread thread;
    private AudioRecord record;
    private long sequence = 0;

    public AudioSender(Context context, DatabaseReference ref) {
        this.context = context.getApplicationContext();
        this.ref = ref;
    }

    public synchronized boolean start() {
        if (running) return true;
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false;

        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) min = SAMPLES_PER_CHUNK * 4;
        int bufferBytes = Math.max(min, SAMPLES_PER_CHUNK * 4);

        try {
            record = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes);
            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                record.release();
                record = null;
                return false;
            }
            record.startRecording();
        } catch (Exception e) {
            if (record != null) try { record.release(); } catch (Exception ignored) {}
            record = null;
            return false;
        }

        running = true;
        uploading = false;
        sequence = System.currentTimeMillis();
        thread = new Thread(this::loop, "AilemVoiceSend");
        thread.start();
        return true;
    }

    private void loop() {
        short[] pcm = new short[SAMPLES_PER_CHUNK];
        while (running && record != null) {
            int n;
            try {
                n = record.read(pcm, 0, pcm.length);
            } catch (Exception e) {
                break;
            }
            if (n <= 0 || uploading) continue;

            byte[] encoded = G711.encode(pcm, n);
            Map<String, Object> m = new HashMap<>();
            m.put("data", Base64.encodeToString(encoded, Base64.NO_WRAP));
            m.put("seq", ++sequence);
            m.put("time", System.currentTimeMillis());
            m.put("rate", SAMPLE_RATE);
            m.put("codec", "mulaw");
            uploading = true;
            ref.setValue(m).addOnCompleteListener(t -> uploading = false);
        }
    }

    public synchronized void stop() {
        running = false;
        uploading = false;
        if (record != null) {
            try { record.stop(); } catch (Exception ignored) {}
            try { record.release(); } catch (Exception ignored) {}
            record = null;
        }
        Thread t = thread;
        thread = null;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
    }

    public boolean isRunning() { return running; }
}
