package com.ailemyanimda.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Base64;
import androidx.core.content.ContextCompat;
import com.google.firebase.database.DatabaseReference;
import java.util.HashMap;
import java.util.Map;

public class AudioSender {
    public static final int SAMPLE_RATE = 8000;
    // ~150 ms: yeterince akici, Firebase'e gereksiz yere cok sik yazmaz.
    private static final int SAMPLES_PER_CHUNK = 1200;

    private final Context context;
    private final DatabaseReference ref;
    private volatile boolean running = false;
    private volatile boolean uploading = false;
    private Thread thread;
    private AudioRecord record;
    private long sequence = 0;

    public AudioSender(Context context, DatabaseReference ref) {
        this.context = context.getApplicationContext();
        this.ref = ref;
    }

    public synchronized boolean start() {
        if (running) return true;
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false;

        // Bazi eski TCL/Android cihazlarda VOICE_COMMUNICATION kaynagi sessiz veya
        // baslatilamamis AudioRecord uretebiliyor. Once normal MIC'i dene, sonra
        // alternatif kaynaklara dus. Bu, uzaktan dinlemenin cihazlar arasinda daha
        // guvenilir calismasini saglar.
        int[] sources = new int[] {
                MediaRecorder.AudioSource.MIC,
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                MediaRecorder.AudioSource.DEFAULT
        };

        for (int source : sources) {
            AudioRecord candidate = createRecord(source);
            if (candidate == null) continue;
            try {
                candidate.startRecording();
                if (candidate.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    record = candidate;
                    break;
                }
            } catch (Exception ignored) {}
            try { candidate.release(); } catch (Exception ignored) {}
        }

        if (record == null) return false;

        running = true;
        uploading = false;
        sequence = System.currentTimeMillis();
        thread = new Thread(this::loop, "AilemVoiceSend");
        thread.start();
        return true;
    }

    private AudioRecord createRecord(int source) {
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) min = SAMPLES_PER_CHUNK * 4;
        int bufferBytes = Math.max(min, SAMPLES_PER_CHUNK * 4);
        try {
            AudioRecord r = new AudioRecord(source, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                try { r.release(); } catch (Exception ignored) {}
                return null;
            }
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    private void loop() {
        short[] pcm = new short[SAMPLES_PER_CHUNK];
        while (running && record != null) {
            int n;
            try {
                n = record.read(pcm, 0, pcm.length);
            } catch (Exception e) {
                break;
            }
            if (n <= 0) continue;
            // Ag/Firebase bir onceki parcayi henuz gonderiyorsa gecikme biriktirme;
            // en guncel sesi korumak icin bu parcayi atla.
            if (uploading) continue;

            byte[] encoded = G711.encode(pcm, n);
            Map<String, Object> m = new HashMap<>();
            m.put("data", Base64.encodeToString(encoded, Base64.NO_WRAP));
            m.put("seq", ++sequence);
            m.put("time", System.currentTimeMillis());
            m.put("rate", SAMPLE_RATE);
            m.put("codec", "mulaw");
            uploading = true;
            ref.setValue(m).addOnCompleteListener(t -> uploading = false);
        }
        // Kayit beklenmedik sekilde durursa durum bayragini yanlis 'calisiyor'
        // halinde birakma.
        running = false;
    }

    public synchronized void stop() {
        running = false;
        uploading = false;
        if (record != null) {
            try { record.stop(); } catch (Exception ignored) {}
            try { record.release(); } catch (Exception ignored) {}
            record = null;
        }
        Thread t = thread;
        thread = null;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
    }

    public boolean isRunning() { return running; }
}
