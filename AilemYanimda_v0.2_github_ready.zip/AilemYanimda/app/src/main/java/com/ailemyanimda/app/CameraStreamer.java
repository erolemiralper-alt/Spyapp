package com.ailemyanimda.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Range;
import android.util.Size;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.google.firebase.database.DatabaseReference;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Akicilik oncelikli kamera aktarimi.
 *
 * Firebase Realtime Database gercek video aktarimi icin tasarlanmamistir. Bu nedenle
 * v0.2.2'de 320x240 + dusuk JPEG kalitesi kullaniyoruz. Kamera sensoru surekli preview
 * uretir; Firebase onceki kareyi gonderirken aradaki kareler biriktirilmez, en yeni kare
 * alinir. Boylece gecikme kuyrugu olusmaz ve "5 saniyede bir fotograf" hissi azalir.
 */
public class CameraStreamer {
    private static final byte JPEG_QUALITY = 22;
    private static final int TARGET_WIDTH = 320;
    private static final int TARGET_HEIGHT = 240;

    private final Context context;
    private final DatabaseReference frameRef;
    private HandlerThread thread;
    private Handler h;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;
    private boolean running = false;
    private String wantedLens = "back";
    private volatile boolean uploading = false;
    private int frameRotation = 90;
    private Rect activeArray;
    private float cameraMaxZoom = 1f;
    private volatile float wantedZoom = 1f;
    private Range<Integer> fpsRange;
    private volatile boolean repeatingActive = false;

    public CameraStreamer(Context c, DatabaseReference ref) {
        context = c.getApplicationContext();
        frameRef = ref;
    }

    public synchronized void start(String lens) {
        if (running && lens.equals(wantedLens)) return;
        stop();
        wantedLens = lens;
        running = true;
        uploading = false;

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            running = false;
            return;
        }

        thread = new HandlerThread("AilemCamera");
        thread.start();
        h = new Handler(thread.getLooper());

        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            String id = findCamera(cm, lens);
            if (id == null) { running = false; return; }

            CameraCharacteristics cc = cm.getCameraCharacteristics(id);
            Integer sensorOrientation = cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
            frameRotation = sensorOrientation == null ? 90 : sensorOrientation;
            activeArray = cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float mz = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            cameraMaxZoom = mz == null ? 1f : Math.max(1f, mz);
            fpsRange = chooseFpsRange(cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES));

            android.hardware.camera2.params.StreamConfigurationMap map =
                    cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size size = chooseSize(map == null ? null : map.getOutputSizes(ImageFormat.JPEG));

            reader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(r -> {
                Image image = null;
                try {
                    // Her zaman en yeni kareyi al. Eski kareler kuyrukta beklemesin.
                    image = r.acquireLatestImage();
                    if (image == null || !running || uploading) return;

                    ByteBuffer buf = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);

                    Map<String,Object> m = new HashMap<>();
                    m.put("jpeg", Base64.encodeToString(bytes, Base64.NO_WRAP));
                    m.put("time", System.currentTimeMillis());
                    m.put("width", size.getWidth());
                    m.put("height", size.getHeight());
                    m.put("rotation", frameRotation);

                    // Ayni anda yalnizca bir Firebase yazimi. Ag yavaslarsa eski kareleri
                    // biriktirmek yerine atliyoruz; sonraki gonderim daima en yeni karedir.
                    uploading = true;
                    frameRef.setValue(m).addOnCompleteListener(t -> uploading = false);
                } catch (Exception ignored) {
                    uploading = false;
                } finally {
                    if (image != null) image.close();
                }
            }, h);

            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(@NonNull CameraDevice c) {
                    device = c;
                    createSession();
                }
                @Override public void onDisconnected(@NonNull CameraDevice c) {
                    c.close();
                    device = null;
                }
                @Override public void onError(@NonNull CameraDevice c, int e) {
                    c.close();
                    device = null;
                }
            }, h);
        } catch (Exception e) {
            stop();
        }
    }

    public void setZoom(float zoom) {
        wantedZoom = Math.max(1f, Math.min(4f, zoom));
        Handler handler = h;
        if (handler != null) handler.post(this::applyRepeatingRequest);
    }

    private String findCamera(CameraManager cm, String lens) throws CameraAccessException {
        int wanted = "front".equals(lens)
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;
        String fallback = null;
        for (String id : cm.getCameraIdList()) {
            if (fallback == null) fallback = id;
            Integer f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
            if (f != null && f == wanted) return id;
        }
        return fallback;
    }

    private Size chooseSize(Size[] sizes) {
        if (sizes == null || sizes.length == 0) return new Size(TARGET_WIDTH, TARGET_HEIGHT);
        Size exact = null;
        Size best = sizes[0];
        long target = (long) TARGET_WIDTH * TARGET_HEIGHT;
        long bestDiff = Long.MAX_VALUE;

        for (Size x : sizes) {
            if (x.getWidth() == TARGET_WIDTH && x.getHeight() == TARGET_HEIGHT) exact = x;
            long area = (long) x.getWidth() * x.getHeight();
            long diff = Math.abs(area - target);
            if (diff < bestDiff) {
                best = x;
                bestDiff = diff;
            }
        }
        return exact != null ? exact : best;
    }

    private Range<Integer> chooseFpsRange(Range<Integer>[] ranges) {
        if (ranges == null || ranges.length == 0) return null;
        Range<Integer> best = ranges[0];
        int bestScore = Integer.MIN_VALUE;
        for (Range<Integer> r : ranges) {
            int lo = r.getLower();
            int hi = r.getUpper();
            // 15-30 veya 15 civari araliklari tercih et; asiri yuksek FPS gereksiz yuk olusturur.
            int score = 0;
            if (lo <= 15 && hi >= 15) score += 1000;
            score -= Math.abs(hi - 20) * 10;
            score -= Math.abs(lo - 10);
            if (score > bestScore) {
                best = r;
                bestScore = score;
            }
        }
        return best;
    }

    private void createSession() {
        try {
            device.createCaptureSession(Collections.singletonList(reader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(@NonNull CameraCaptureSession s) {
                            session = s;
                            applyRepeatingRequest();
                        }
                        @Override public void onConfigureFailed(@NonNull CameraCaptureSession s) {}
                    }, h);
        } catch (Exception e) {
            stop();
        }
    }

    private Rect cropForZoom(float requested) {
        Rect a = activeArray;
        if (a == null) return null;
        float z = Math.max(1f, Math.min(Math.min(4f, cameraMaxZoom), requested));
        if (z <= 1.01f) return a;
        int cropW = Math.max(1, Math.round(a.width() / z));
        int cropH = Math.max(1, Math.round(a.height() / z));
        int left = a.centerX() - cropW / 2;
        int top = a.centerY() - cropH / 2;
        return new Rect(left, top, left + cropW, top + cropH);
    }

    private CaptureRequest buildRequest(int template) throws CameraAccessException {
        CameraDevice d = device;
        ImageReader r = reader;
        if (d == null || r == null) return null;
        CaptureRequest.Builder b = d.createCaptureRequest(template);
        b.addTarget(r.getSurface());
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        if (fpsRange != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fpsRange);
        b.set(CaptureRequest.JPEG_QUALITY, JPEG_QUALITY);
        Rect crop = cropForZoom(wantedZoom);
        if (crop != null) b.set(CaptureRequest.SCALER_CROP_REGION, crop);
        return b.build();
    }

    private void applyRepeatingRequest() {
        CameraCaptureSession s = session;
        Handler handler = h;
        if (!running || device == null || s == null || reader == null || handler == null) return;
        try {
            CaptureRequest req = buildRequest(CameraDevice.TEMPLATE_PREVIEW);
            if (req == null) return;
            s.setRepeatingRequest(req, null, handler);
            repeatingActive = true;
            handler.removeCallbacks(fallbackCaptureLoop);
        } catch (Exception ignored) {
            // Bazi eski cihazlar JPEG yuzeyinde repeating preview kabul etmiyor.
            // Bu durumda eski uyumlu yonteme geri don, ama yine dusuk boyut/kalite kullan.
            repeatingActive = false;
            handler.removeCallbacks(fallbackCaptureLoop);
            handler.post(fallbackCaptureLoop);
        }
    }

    private final Runnable fallbackCaptureLoop = new Runnable() {
        @Override public void run() {
            CameraCaptureSession s = session;
            Handler handler = h;
            if (!running || repeatingActive || s == null || device == null || handler == null) return;
            try {
                CaptureRequest req = buildRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                if (req != null) s.capture(req, null, handler);
            } catch (Exception ignored) {}
            if (h != null) h.postDelayed(this, 80L);
        }
    };

    public synchronized void stop() {
        running = false;
        uploading = false;
        repeatingActive = false;
        if (h != null) h.removeCallbacksAndMessages(null);
        try { if (session != null) session.stopRepeating(); } catch (Exception ignored) {}
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (device != null) device.close(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        session = null;
        device = null;
        reader = null;
        activeArray = null;
        cameraMaxZoom = 1f;
        fpsRange = null;
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
        h = null;
    }
}
