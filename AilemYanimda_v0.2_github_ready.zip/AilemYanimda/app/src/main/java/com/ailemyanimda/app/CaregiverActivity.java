package com.ailemyanimda.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CaregiverActivity extends AppCompatActivity {
    private static final int REQ_AUDIO = 77;
    private static final long ONLINE_STALE_MS = 12_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private DatabaseReference base;
    private DatabaseReference infoConnected;
    private TextView connectionBadge, connectionDetail, voiceStatus, zoomText;
    private ZoomImageView camera;
    private Button camButton, flipButton, listenButton, talkButton;
    private boolean cameraOn = false;
    private boolean listening = false;
    private boolean talking = false;
    private boolean restoreListenAfterTalk = false;
    private boolean localFirebaseConnected = false;
    private boolean remoteReportedOnline = false;
    private long remoteLastSeen = 0L;
    private String lens = "back";
    private float cameraZoom = 1f;
    private ValueEventListener statusListener, frameListener, localConnectionListener;
    private AudioPlayer remoteAudio;
    private AudioSender talkAudio;
    private Bitmap displayedBitmap;
    private final Object frameLock = new Object();
    private final ExecutorService frameExecutor = Executors.newSingleThreadExecutor();
    private FramePacket pendingFrame;
    private boolean frameDecodeRunning = false;
    private long lastDisplayedFrameTime = 0L;

    private static class FramePacket {
        final String jpeg;
        final long time;
        final int rotation;
        FramePacket(String jpeg, long time, int rotation) {
            this.jpeg = jpeg;
            this.time = time;
            this.rotation = rotation;
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "Ailem Yanımda", "Canlı kamera ve ses"));

        LinearLayout statusCard = Ui.card(this);
        connectionBadge = Ui.badge(this, "● BAĞLANTI KAPALI", Ui.RED);
        connectionDetail = Ui.text(this, "Bağlantı kontrol ediliyor…", 14);
        connectionDetail.setGravity(Gravity.CENTER);
        connectionDetail.setTextColor(Ui.MUTED);
        statusCard.addView(connectionBadge);
        statusCard.addView(connectionDetail);
        root.addView(statusCard);

        LinearLayout cameraCard = Ui.card(this);
        cameraCard.addView(Ui.sectionTitle(this, "Kamera"));
        camButton = Ui.button(this, "Kamera KAPALI", Ui.RED);
        flipButton = Ui.button(this, "Kamera: Arka", Ui.NAVY);
        cameraCard.addView(camButton);
        cameraCard.addView(flipButton);

        camera = new ZoomImageView(this);
        camera.setBackgroundColor(0xff0c1118);
        camera.setLayoutParams(new LinearLayout.LayoutParams(-1, Ui.dp(this, 520)));
        cameraCard.addView(camera);

        LinearLayout zoomRow = new LinearLayout(this);
        zoomRow.setOrientation(LinearLayout.HORIZONTAL);
        zoomRow.setGravity(Gravity.CENTER_VERTICAL);
        zoomRow.setPadding(0, Ui.dp(this,8), 0, 0);
        Button zoomOut = Ui.compactButton(this, "−", Ui.NAVY);
        Button zoomIn = Ui.compactButton(this, "+", Ui.NAVY);
        zoomText = Ui.text(this, "1.0×", 17);
        zoomText.setGravity(Gravity.CENTER);
        zoomText.setTypeface(null, 1);
        zoomRow.addView(zoomOut, new LinearLayout.LayoutParams(0, Ui.dp(this,52), 1f));
        LinearLayout.LayoutParams zlp = new LinearLayout.LayoutParams(0, Ui.dp(this,52), 1.4f);
        zlp.setMargins(Ui.dp(this,8), 0, Ui.dp(this,8), 0);
        zoomRow.addView(zoomText, zlp);
        zoomRow.addView(zoomIn, new LinearLayout.LayoutParams(0, Ui.dp(this,52), 1f));
        cameraCard.addView(zoomRow);

        TextView zoomHint = Ui.text(this, "Uzak kamera zoomu: − / +   •   Görüntü: iki parmakla yakınlaştır", 13);
        zoomHint.setGravity(Gravity.CENTER);
        zoomHint.setTextColor(Ui.MUTED);
        cameraCard.addView(zoomHint);
        root.addView(cameraCard);

        LinearLayout audioCard = Ui.card(this);
        audioCard.addView(Ui.sectionTitle(this, "Sesli iletişim"));
        listenButton = Ui.button(this, "Dinleme KAPALI", Ui.RED);
        talkButton = Ui.button(this, "Basılı tut ve konuş", 0xffa15c09);
        voiceStatus = Ui.text(this, "Ses kapalı", 14);
        voiceStatus.setGravity(Gravity.CENTER);
        voiceStatus.setTextColor(Ui.MUTED);
        audioCard.addView(listenButton);
        audioCard.addView(talkButton);
        audioCard.addView(voiceStatus);
        root.addView(audioCard);

        TextView privacy = Ui.text(this, "Kamera veya mikrofon açıldığında diğer telefonda görünür bildirim gösterilir.", 12);
        privacy.setGravity(Gravity.CENTER);
        privacy.setTextColor(Ui.MUTED);
        root.addView(privacy);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);

        camera.post(this::setCameraViewport);

        camButton.setOnClickListener(v -> {
            cameraOn = !cameraOn;
            if (base != null) base.child("commands/cameraEnabled").setValue(cameraOn);
            updateCameraButton();
        });

        flipButton.setOnClickListener(v -> {
            lens = "back".equals(lens) ? "front" : "back";
            if (base != null) base.child("commands/lens").setValue(lens);
            flipButton.setText("Kamera: " + ("back".equals(lens) ? "Arka" : "Ön"));
        });

        zoomOut.setOnClickListener(v -> setRemoteZoom(cameraZoom - 0.5f));
        zoomIn.setOnClickListener(v -> setRemoteZoom(cameraZoom + 0.5f));
        zoomText.setOnClickListener(v -> setRemoteZoom(1f));

        listenButton.setOnClickListener(v -> toggleListening());
        talkButton.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                beginTalking();
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                endTalking();
                v.performClick();
                return true;
            }
            return true;
        });

        connect();
        handler.post(connectionTicker);
    }

    private void setCameraViewport() {
        if (camera == null) return;
        int w = camera.getWidth();
        int h = w > 0 ? Math.round(w * 1.28f) : Ui.dp(this, 520);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) camera.getLayoutParams();
        lp.height = h;
        camera.setLayoutParams(lp);
    }

    private void setRemoteZoom(float z) {
        cameraZoom = Math.max(1f, Math.min(4f, Math.round(z * 2f) / 2f));
        zoomText.setText(String.format(Locale.US, "%.1f×", cameraZoom));
        if (base != null) base.child("commands/cameraZoom").setValue(cameraZoom);
    }

    private void updateCameraButton() {
        camButton.setText(cameraOn ? "Kamera AÇIK" : "Kamera KAPALI");
        Ui.setButtonColor(camButton, cameraOn ? Ui.GREEN : Ui.RED);
    }

    private void updateListenButton() {
        listenButton.setText(listening ? "Dinleme AÇIK" : "Dinleme KAPALI");
        Ui.setButtonColor(listenButton, listening ? Ui.GREEN : Ui.RED);
    }

    private void toggleListening() {
        if (base == null) return;
        listening = !listening;
        if (listening) {
            if (remoteAudio != null && !talking) remoteAudio.start();
            base.child("commands/audioEnabled").setValue(true);
            voiceStatus.setText("Karşı tarafın sesi dinleniyor");
        } else {
            base.child("commands/audioEnabled").setValue(false);
            if (remoteAudio != null) remoteAudio.stop();
            voiceStatus.setText("Ses kapalı");
        }
        updateListenButton();
    }

    private void beginTalking() {
        if (talking || base == null) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            Toast.makeText(this, "Konuşmak için mikrofon izni verin.", Toast.LENGTH_LONG).show();
            return;
        }

        talking = true;
        restoreListenAfterTalk = listening;
        if (restoreListenAfterTalk) {
            base.child("commands/audioEnabled").setValue(false);
            if (remoteAudio != null) remoteAudio.stop();
        }
        talkButton.setText("Konuşuyorsun…");
        Ui.setButtonColor(talkButton, Ui.RED);
        voiceStatus.setText("Sesiniz karşı telefona gönderiliyor");

        // Eski surumlerde daha iyi calisan davranis: Firebase komutunun sunucudan
        // onayini beklemeden mikrofona hemen basla. Karsi telefon dinlemeyi actiginda
        // tek-parca ses dugumundeki en guncel paket otomatik gelir.
        base.child("commands/caregiverTalking").setValue(true);
        if (talkAudio != null && !talkAudio.start()) {
            Toast.makeText(this, "Mikrofon başlatılamadı.", Toast.LENGTH_LONG).show();
        }
    }

    private void endTalking() {
        if (!talking) return;
        talking = false;
        if (talkAudio != null) talkAudio.stop();
        if (base != null) base.child("commands/caregiverTalking").setValue(false);
        talkButton.setText("Basılı tut ve konuş");
        Ui.setButtonColor(talkButton, 0xffa15c09);

        if (restoreListenAfterTalk && listening && base != null) {
            if (remoteAudio != null) remoteAudio.start();
            base.child("commands/audioEnabled").setValue(true);
            voiceStatus.setText("Karşı tarafın sesi dinleniyor");
        } else {
            voiceStatus.setText(listening ? "Karşı tarafın sesi dinleniyor" : "Ses kapalı");
        }
        restoreListenAfterTalk = false;
    }

    private void connect() {
        FirebaseAuth a = FirebaseProvider.auth(this);
        Runnable go = () -> {
            String secret = AppPrefs.secret(this);
            if (secret.isEmpty()) {
                Toast.makeText(this, "Eşleştirme bulunamadı.", Toast.LENGTH_LONG).show();
                return;
            }
            FirebaseDatabase db = FirebaseProvider.db(this);
            base = db.getReference("families").child(secret);
            infoConnected = db.getReference(".info/connected");
            remoteAudio = new AudioPlayer(this, base.child("audio/fromTracked"));
            talkAudio = new AudioSender(this, base.child("audio/fromCaregiver"));
            base.child("commands/cameraZoom").setValue(cameraZoom);
            listen();
        };
        if (a.getCurrentUser() != null) go.run();
        else a.signInAnonymously()
                .addOnSuccessListener(x -> go.run())
                .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void listen() {
        localConnectionListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                localFirebaseConnected = Boolean.TRUE.equals(s.getValue(Boolean.class));
                refreshConnectionUi();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                localFirebaseConnected = false;
                refreshConnectionUi();
            }
        };
        infoConnected.addValueEventListener(localConnectionListener);

        statusListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                remoteReportedOnline = Boolean.TRUE.equals(s.child("online").getValue(Boolean.class));
                Long seen = s.child("lastSeen").getValue(Long.class);
                remoteLastSeen = seen == null ? 0L : seen;

                Boolean cameraPermissionMissing = s.child("cameraPermissionMissing").getValue(Boolean.class);
                Boolean audioMissing = s.child("audioPermissionMissing").getValue(Boolean.class);
                Boolean audioFailed = s.child("audioCaptureFailed").getValue(Boolean.class);
                if (Boolean.TRUE.equals(cameraPermissionMissing) && cameraOn) {
                    Toast.makeText(CaregiverActivity.this, "Karşı telefonda kamera izni gerekli.", Toast.LENGTH_LONG).show();
                }
                if (Boolean.TRUE.equals(audioMissing) && listening) {
                    voiceStatus.setText("Karşı telefonda mikrofon izni gerekli");
                } else if (Boolean.TRUE.equals(audioFailed) && listening) {
                    voiceStatus.setText("Mikrofon başlatılamadı — tekrar deneyin");
                }
                refreshConnectionUi();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                remoteReportedOnline = false;
                refreshConnectionUi();
            }
        };

        frameListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                String jpeg = s.child("jpeg").getValue(String.class);
                Long time = s.child("time").getValue(Long.class);
                Long rv = s.child("rotation").getValue(Long.class);
                if (jpeg == null || time == null || System.currentTimeMillis() - time > 2500L) return;
                int rotation = rv == null ? 90 : rv.intValue();
                queueFrame(new FramePacket(jpeg, time, rotation));
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        base.child("status").addValueEventListener(statusListener);
        base.child("camera/frame").addValueEventListener(frameListener);
    }


    private void queueFrame(FramePacket packet) {
        synchronized (frameLock) {
            // Dekoder yetisemezse eski kareyi ez. Boylece goruntu gecikmeli bir slayt
            // kuyruguna donusmez; her zaman en yeni kare islenir.
            pendingFrame = packet;
            if (frameDecodeRunning) return;
            frameDecodeRunning = true;
        }
        frameExecutor.execute(this::decodeFrameLoop);
    }

    private void decodeFrameLoop() {
        while (true) {
            FramePacket packet;
            synchronized (frameLock) {
                packet = pendingFrame;
                pendingFrame = null;
                if (packet == null) {
                    frameDecodeRunning = false;
                    return;
                }
            }

            if (System.currentTimeMillis() - packet.time > 2500L) continue;
            Bitmap bm = null;
            try {
                byte[] bytes = Base64.decode(packet.jpeg, Base64.DEFAULT);
                bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bm == null) continue;
                int rotation = ((packet.rotation % 360) + 360) % 360;
                if (rotation != 0) {
                    Matrix mx = new Matrix();
                    mx.postRotate(rotation);
                    Bitmap rotated = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mx, false);
                    if (rotated != bm) bm.recycle();
                    bm = rotated;
                }
            } catch (Exception ignored) {
                if (bm != null && !bm.isRecycled()) bm.recycle();
                continue;
            }

            final Bitmap ready = bm;
            handler.post(() -> {
                if (isFinishing() || isDestroyed() || packet.time < lastDisplayedFrameTime) {
                    if (!ready.isRecycled()) ready.recycle();
                    return;
                }
                lastDisplayedFrameTime = packet.time;
                Bitmap old = displayedBitmap;
                displayedBitmap = ready;
                camera.setImageBitmap(ready);
                if (old != null && old != ready && !old.isRecycled()) old.recycle();
            });
        }
    }

    private final Runnable connectionTicker = new Runnable() {
        @Override public void run() {
            refreshConnectionUi();
            handler.postDelayed(this, 2_000L);
        }
    };

    private void refreshConnectionUi() {
        if (connectionBadge == null) return;
        long now = System.currentTimeMillis();
        boolean fresh = remoteLastSeen == 0L || now - remoteLastSeen <= ONLINE_STALE_MS;
        boolean online = localFirebaseConnected && remoteReportedOnline && fresh;
        if (online) {
            Ui.setBadge(connectionBadge, "● BAĞLANTI AÇIK", Ui.GREEN);
            connectionDetail.setText("Telefon bağlı");
        } else {
            Ui.setBadge(connectionBadge, "● BAĞLANTI KAPALI", Ui.RED);
            if (!localFirebaseConnected) {
                connectionDetail.setText("İnternet / Firebase bağlantısı yok");
            } else if (remoteLastSeen > 0L) {
                connectionDetail.setText("Son bağlantı: " + DateFormat.getDateTimeInstance().format(new Date(remoteLastSeen)));
            } else {
                connectionDetail.setText("Karşı telefon bekleniyor");
            }
        }
    }

    @Override protected void onStop() {
        super.onStop();
        if (base != null) {
            if (cameraOn) {
                cameraOn = false;
                base.child("commands/cameraEnabled").setValue(false);
                updateCameraButton();
            }
            if (listening) {
                listening = false;
                base.child("commands/audioEnabled").setValue(false);
                updateListenButton();
            }
        }
        endTalking();
        if (remoteAudio != null) remoteAudio.stop();
        if (talkAudio != null) talkAudio.stop();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        synchronized (frameLock) { pendingFrame = null; }
        frameExecutor.shutdownNow();
        if (remoteAudio != null) remoteAudio.stop();
        if (talkAudio != null) talkAudio.stop();
        if (base != null) {
            if (statusListener != null) base.child("status").removeEventListener(statusListener);
            if (frameListener != null) base.child("camera/frame").removeEventListener(frameListener);
        }
        if (infoConnected != null && localConnectionListener != null) {
            infoConnected.removeEventListener(localConnectionListener);
        }
        if (displayedBitmap != null && !displayedBitmap.isRecycled()) {
            camera.setImageDrawable(null);
            displayedBitmap.recycle();
            displayedBitmap = null;
        }
        super.onDestroy();
    }
}
