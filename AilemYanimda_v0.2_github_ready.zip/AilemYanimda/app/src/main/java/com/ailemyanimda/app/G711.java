package com.ailemyanimda.app;

public final class G711 {
    private static final int BIAS = 0x84;
    private static final int CLIP = 32635;

    private G711() {}

    public static byte[] encode(short[] pcm, int length) {
        byte[] out = new byte[length];
        for (int i = 0; i < length; i++) out[i] = linearToMuLaw(pcm[i]);
        return out;
    }

    public static short[] decode(byte[] ulaw) {
        short[] out = new short[ulaw.length];
        for (int i = 0; i < ulaw.length; i++) out[i] = muLawToLinear(ulaw[i]);
        return out;
    }

    private static byte linearToMuLaw(short sample) {
        int pcm = sample;
        int sign = (pcm >> 8) & 0x80;
        if (sign != 0) pcm = -pcm;
        if (pcm > CLIP) pcm = CLIP;
        pcm += BIAS;

        int exponent = 7;
        for (int mask = 0x4000; (pcm & mask) == 0 && exponent > 0; exponent--, mask >>= 1) {}
        int mantissa = (pcm >> (exponent + 3)) & 0x0F;
        return (byte) ~(sign | (exponent << 4) | mantissa);
    }

    private static short muLawToLinear(byte value) {
        int u = (~value) & 0xFF;
        int sign = u & 0x80;
        int exponent = (u >> 4) & 0x07;
        int mantissa = u & 0x0F;
        int sample = ((mantissa << 3) + BIAS) << exponent;
        sample -= BIAS;
        return (short) (sign != 0 ? -sample : sample);
    }
}
