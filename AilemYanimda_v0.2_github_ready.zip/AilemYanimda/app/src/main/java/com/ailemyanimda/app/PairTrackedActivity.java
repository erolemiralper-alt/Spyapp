package com.ailemyanimda.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import androidx.annotation.NonNull;

public class PairTrackedActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); LinearLayout r=Ui.root(this); r.addView(Ui.title(this,"Annemin telefonunu bağla"));
        r.addView(Ui.text(this,"Kendi telefonunuzda görünen 8 haneli kodu yazın.",17));
        EditText code=new EditText(this); code.setHint("00000000"); code.setTextSize(28); code.setGravity(android.view.Gravity.CENTER);
        code.setInputType(InputType.TYPE_CLASS_NUMBER); r.addView(code);
        android.widget.Button pair=Ui.button(this,"Eşleştir",0xff2ead5b); r.addView(pair); setContentView(r);
        pair.setOnClickListener(v->{ String c=code.getText().toString().trim(); if(c.length()!=8){toast("8 haneli kodu girin.");return;} authenticateAndPair(c); });
    }
    private void authenticateAndPair(String code){
        FirebaseAuth a=FirebaseProvider.auth(this);
        Runnable go=()->FirebaseProvider.db(this).getReference("pairCodes").child(code).addListenerForSingleValueEvent(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){
                String secret=s.child("secret").getValue(String.class); Long exp=s.child("expiresAt").getValue(Long.class);
                if(secret==null || exp==null || exp<System.currentTimeMillis()){toast("Kod geçersiz veya süresi dolmuş.");return;}
                AppPrefs.put(PairTrackedActivity.this,"role","tracked"); AppPrefs.put(PairTrackedActivity.this,"family_secret",secret);
                FirebaseProvider.db(PairTrackedActivity.this).getReference("families").child(secret).child("status/model").setValue(android.os.Build.MODEL);
                startActivity(new Intent(PairTrackedActivity.this,TrackedActivity.class)); finishAffinity();
            }
            @Override public void onCancelled(@NonNull DatabaseError e){toast(e.getMessage());}
        });
        if(a.getCurrentUser()!=null)go.run(); else a.signInAnonymously().addOnSuccessListener(x->go.run()).addOnFailureListener(e->toast(e.getMessage()));
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
