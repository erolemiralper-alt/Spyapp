package com.ailemyanimda.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class RoleActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout r = Ui.root(this);
        r.addView(Ui.header(this, "Ailem Yanımda", "İki telefonu bir kez eşleştir"));
        LinearLayout card = Ui.card(this);
        android.widget.Button mine = Ui.button(this, "Kontrol telefonu", Ui.BLUE);
        android.widget.Button remote = Ui.button(this, "Kamera telefonu", Ui.GREEN);
        mine.setOnClickListener(v -> startActivity(new Intent(this, CreateFamilyActivity.class)));
        remote.setOnClickListener(v -> startActivity(new Intent(this, PairTrackedActivity.class)));
        card.addView(mine);
        card.addView(remote);
        r.addView(card);
        setContentView(r);
    }
}
