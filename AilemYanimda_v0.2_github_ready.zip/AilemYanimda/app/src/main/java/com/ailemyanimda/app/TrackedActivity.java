package com.ailemyanimda.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class TrackedActivity extends AppCompatActivity {
    private static final int REQ = 42;
    private TextView connectionBadge, cameraState, audioState;
    private DatabaseReference infoConnected, commands;
    private ValueEventListener connectionListener, commandsListener;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "Ailem Yanımda", "Kamera telefonu"));

        LinearLayout stateCard = Ui.card(this);
        connectionBadge = Ui.badge(this, "● BAĞLANTI HAZIRLANIYOR", Ui.NAVY);
        cameraState = Ui.text(this, "Kamera: Kapalı", 16);
        audioState = Ui.text(this, "Mikrofon: Kapalı", 16);
        cameraState.setGravity(Gravity.CENTER);
        audioState.setGravity(Gravity.CENTER);
        stateCard.addView(connectionBadge);
        stateCard.addView(cameraState);
        stateCard.addView(audioState);
        root.addView(stateCard);

        LinearLayout actions = Ui.card(this);
        Button permission = Ui.button(this, "Kamera ve mikrofon izinleri", Ui.BLUE);
        Button start = Ui.button(this, "Bağlantıyı başlat", Ui.GREEN);
        permission.setOnClickListener(v -> askPermissions());
        start.setOnClickListener(v -> startLiveService());
        actions.addView(permission);
        actions.addView(start);
        root.addView(actions);

        TextView note = Ui.text(this, "Kamera veya mikrofon kullanılırken bildirim ekranda görünür.", 13);
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Ui.MUTED);
        root.addView(note);
        setContentView(root);

        bindUiStatus();
        askPermissions();
    }

    private void askPermissions() {
        java.util.ArrayList<String> p = new java.util.ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.CAMERA);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (p.isEmpty()) startLiveService();
        else ActivityCompat.requestPermissions(this, p.toArray(new String[0]), REQ);
    }

    @Override public void onRequestPermissionsResult(int r, @NonNull String[] p, @NonNull int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ) startLiveService();
    }

    private void startLiveService() {
        Intent i = new Intent(this, TrackingService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, i);
            else startService(i);
            Toast.makeText(this, "Bağlantı etkin.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Bağlantı başlatılamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void bindUiStatus() {
        infoConnected = FirebaseProvider.db(this).getReference(".info/connected");
        connectionListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                boolean on = Boolean.TRUE.equals(s.getValue(Boolean.class));
                Ui.setBadge(connectionBadge, on ? "● BAĞLANTI AÇIK" : "● BAĞLANTI KAPALI", on ? Ui.GREEN : Ui.RED);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                Ui.setBadge(connectionBadge, "● BAĞLANTI KAPALI", Ui.RED);
            }
        };
        infoConnected.addValueEventListener(connectionListener);

        String secret = AppPrefs.secret(this);
        if (!secret.isEmpty()) {
            commands = FirebaseProvider.db(this).getReference("families").child(secret).child("commands");
            commandsListener = new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot s) {
                    boolean cam = Boolean.TRUE.equals(s.child("cameraEnabled").getValue(Boolean.class));
                    boolean mic = Boolean.TRUE.equals(s.child("audioEnabled").getValue(Boolean.class));
                    boolean talk = Boolean.TRUE.equals(s.child("caregiverTalking").getValue(Boolean.class));
                    cameraState.setText("Kamera: " + (cam ? "Açık" : "Kapalı"));
                    cameraState.setTextColor(cam ? Ui.GREEN : Ui.TEXT);
                    audioState.setText("Ses: " + ((mic || talk) ? "Açık" : "Kapalı"));
                    audioState.setTextColor((mic || talk) ? Ui.GREEN : Ui.TEXT);
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {}
            };
            commands.addValueEventListener(commandsListener);
        }
    }

    @Override protected void onDestroy() {
        if (infoConnected != null && connectionListener != null) infoConnected.removeEventListener(connectionListener);
        if (commands != null && commandsListener != null) commands.removeEventListener(commandsListener);
        super.onDestroy();
    }
}
