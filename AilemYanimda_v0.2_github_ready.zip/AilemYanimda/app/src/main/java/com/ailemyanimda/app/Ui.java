package com.ailemyanimda.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static LinearLayout root(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c,20), dp(c,22), dp(c,20), dp(c,22));
        l.setBackgroundColor(Color.rgb(245,248,252));
        return l;
    }
    public static TextView title(Context c, String s) {
        TextView v = new TextView(c); v.setText(s); v.setTextSize(27); v.setTextColor(Color.rgb(20,32,51));
        v.setGravity(Gravity.CENTER); v.setPadding(0,0,0,dp(c,16)); v.setTypeface(null,1); return v;
    }
    public static TextView text(Context c, String s, int size) {
        TextView v = new TextView(c); v.setText(s); v.setTextSize(size); v.setTextColor(Color.rgb(20,32,51));
        v.setPadding(dp(c,12),dp(c,10),dp(c,12),dp(c,10)); return v;
    }
    public static Button button(Context c, String s, int color) {
        Button b = new Button(c); b.setText(s); b.setTextSize(18); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(c,16)); b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c,62)); lp.setMargins(0,dp(c,8),0,dp(c,8)); b.setLayoutParams(lp); return b;
    }
    public static View spacer(Context c, int h) { View v = new View(c); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(c,h))); return v; }
    public static int dp(Context c, int n) { return (int)(n*c.getResources().getDisplayMetrics().density + .5f); }
}
