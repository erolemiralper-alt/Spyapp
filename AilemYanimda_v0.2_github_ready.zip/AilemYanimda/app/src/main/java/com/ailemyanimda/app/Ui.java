package com.ailemyanimda.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int NAVY = 0xff17365d;
    public static final int BLUE = 0xff1769d2;
    public static final int GREEN = 0xff2ead5b;
    public static final int RED = 0xffd93a36;
    public static final int TEXT = 0xff142033;
    public static final int MUTED = 0xff667085;
    public static final int SOFT = 0xfff3f6fa;

    public static LinearLayout root(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c,18), dp(c,20), dp(c,18), dp(c,28));
        l.setBackgroundColor(0xfff4f7fb);
        return l;
    }

    public static LinearLayout header(Context c, String title, String subtitle) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(c,12), dp(c,8), dp(c,12), dp(c,12));

        ImageView logo = new ImageView(c);
        logo.setImageResource(com.ailemyanimda.app.R.drawable.ic_logo);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(c,72), dp(c,72));
        ilp.gravity = Gravity.CENTER;
        logo.setLayoutParams(ilp);
        box.addView(logo);

        TextView t = title(c, title);
        t.setPadding(0, dp(c,8), 0, 0);
        box.addView(t);
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = text(c, subtitle, 14);
            s.setTextColor(MUTED);
            s.setGravity(Gravity.CENTER);
            s.setPadding(dp(c,8), dp(c,4), dp(c,8), 0);
            box.addView(s);
        }
        return box;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c,14), dp(c,14), dp(c,14), dp(c,14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(c,18));
        g.setStroke(dp(c,1), 0xffe4eaf2);
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(c,8), 0, dp(c,8));
        l.setLayoutParams(lp);
        return l;
    }

    public static TextView title(Context c, String s) {
        TextView v = new TextView(c);
        v.setText(s);
        v.setTextSize(27);
        v.setTextColor(TEXT);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0,0,0,dp(c,10));
        v.setTypeface(null,1);
        return v;
    }

    public static TextView sectionTitle(Context c, String s) {
        TextView v = text(c, s, 18);
        v.setTypeface(null, 1);
        v.setPadding(dp(c,2), dp(c,4), dp(c,2), dp(c,8));
        return v;
    }

    public static TextView text(Context c, String s, int size) {
        TextView v = new TextView(c);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(TEXT);
        v.setPadding(dp(c,8),dp(c,8),dp(c,8),dp(c,8));
        return v;
    }

    public static TextView badge(Context c, String s, int color) {
        TextView v = text(c, s, 16);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(null, 1);
        v.setTextColor(Color.WHITE);
        setPillColor(c, v, color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c,48));
        lp.setMargins(0, dp(c,4), 0, dp(c,6));
        v.setLayoutParams(lp);
        return v;
    }

    public static void setBadge(TextView v, String text, int color) {
        v.setText(text);
        v.setTextColor(Color.WHITE);
        setPillColor(v.getContext(), v, color);
    }

    private static void setPillColor(Context c, TextView v, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c,16));
        v.setBackground(g);
    }

    public static Button button(Context c, String s, int color) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(null, 1);
        setButtonColor(b, color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c,58));
        lp.setMargins(0,dp(c,6),0,dp(c,6));
        b.setLayoutParams(lp);
        return b;
    }

    public static Button compactButton(Context c, String s, int color) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(18);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(null, 1);
        setButtonColor(b, color);
        return b;
    }

    public static void setButtonColor(Button b, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(b.getContext(),16));
        b.setBackground(g);
    }

    public static View spacer(Context c, int h) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(c,h)));
        return v;
    }

    public static int dp(Context c, int n) {
        return (int)(n*c.getResources().getDisplayMetrics().density + .5f);
    }
}
