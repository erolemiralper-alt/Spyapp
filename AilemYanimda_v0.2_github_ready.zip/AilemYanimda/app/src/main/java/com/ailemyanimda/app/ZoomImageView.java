package com.ailemyanimda.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import androidx.appcompat.widget.AppCompatImageView;

/** Kamera karesini iki parmakla 1x-4x yakinlastirmaya ve suruklemeye yarar. */
public class ZoomImageView extends AppCompatImageView {
    private final Matrix matrix = new Matrix();
    private final ScaleGestureDetector scaler;
    private final GestureDetector gestures;
    private float userScale = 1f;
    private float lastX, lastY;
    private boolean initialized = false;
    private int lastDw = -1, lastDh = -1;

    public ZoomImageView(Context context) {
        super(context);
        setScaleType(ScaleType.MATRIX);
        scaler = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float target = clamp(userScale * d.getScaleFactor(), 1f, 4f);
                float factor = target / userScale;
                userScale = target;
                matrix.postScale(factor, factor, d.getFocusX(), d.getFocusY());
                fixBounds();
                setImageMatrix(matrix);
                return true;
            }
        });
        gestures = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                resetZoom();
                return true;
            }
        });
    }

    @Override public void setImageBitmap(Bitmap bm) {
        int w = bm == null ? -1 : bm.getWidth();
        int h = bm == null ? -1 : bm.getHeight();
        boolean changedSize = w != lastDw || h != lastDh;
        super.setImageBitmap(bm);
        lastDw = w; lastDh = h;
        if (!initialized || changedSize) post(this::resetZoom);
        else setImageMatrix(matrix);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0) post(this::resetZoom);
    }

    public void resetZoom() {
        Drawable d = getDrawable();
        int vw = getWidth() - getPaddingLeft() - getPaddingRight();
        int vh = getHeight() - getPaddingTop() - getPaddingBottom();
        if (d == null || vw <= 0 || vh <= 0 || d.getIntrinsicWidth() <= 0 || d.getIntrinsicHeight() <= 0) return;
        float fit = Math.min(vw / (float) d.getIntrinsicWidth(), vh / (float) d.getIntrinsicHeight());
        float dx = getPaddingLeft() + (vw - d.getIntrinsicWidth() * fit) / 2f;
        float dy = getPaddingTop() + (vh - d.getIntrinsicHeight() * fit) / 2f;
        matrix.reset();
        matrix.postScale(fit, fit);
        matrix.postTranslate(dx, dy);
        userScale = 1f;
        initialized = true;
        setImageMatrix(matrix);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (getDrawable() == null) return true;
        getParent().requestDisallowInterceptTouchEvent(true);
        gestures.onTouchEvent(e);
        scaler.onTouchEvent(e);

        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            lastX = e.getX(); lastY = e.getY();
        } else if (a == MotionEvent.ACTION_MOVE && e.getPointerCount() == 1 && !scaler.isInProgress() && userScale > 1f) {
            float dx = e.getX() - lastX, dy = e.getY() - lastY;
            matrix.postTranslate(dx, dy);
            fixBounds();
            setImageMatrix(matrix);
            lastX = e.getX(); lastY = e.getY();
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            getParent().requestDisallowInterceptTouchEvent(false);
        }
        return true;
    }

    private void fixBounds() {
        Drawable d = getDrawable();
        if (d == null) return;
        RectF r = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        matrix.mapRect(r);
        float left = getPaddingLeft(), top = getPaddingTop();
        float right = getWidth() - getPaddingRight(), bottom = getHeight() - getPaddingBottom();
        float dx = 0, dy = 0;

        if (r.width() <= right - left) dx = (left + right) / 2f - r.centerX();
        else if (r.left > left) dx = left - r.left;
        else if (r.right < right) dx = right - r.right;

        if (r.height() <= bottom - top) dy = (top + bottom) / 2f - r.centerY();
        else if (r.top > top) dy = top - r.top;
        else if (r.bottom < bottom) dy = bottom - r.bottom;

        matrix.postTranslate(dx, dy);
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
