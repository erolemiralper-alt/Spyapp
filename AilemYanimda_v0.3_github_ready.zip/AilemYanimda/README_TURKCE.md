# Ailem Yanımda — v0.3.0

Aynı APK iki telefonda kullanılır. Bu sürüm yalnızca **kamera, sesli iletişim ve bağlantı durumu** için tasarlanmıştır.

## v0.3.0 değişiklikleri

- Konum, harita, konum geçmişi, SOS ve pil yüzdesi özellikleri kaldırıldı.
- Eski konum/geçmiş/SOS/pil verileri kamera telefonunun servisi başladığında Firebase'den temizlenir.
- Bağlantı durumu Firebase presence + 5 saniyelik heartbeat ile izlenir. Kontrol ekranında **BAĞLANTI AÇIK** yeşil, bağlantı kesildiğinde **BAĞLANTI KAPALI** kırmızı gösterilir.
- Kamera düğmesi kapalıyken kırmızı, açıkken yeşildir.
- Kamera görüntü alanı kalıcı olarak büyütüldü; eski “kamera alanını büyüt/küçült” düğmesi kaldırıldı.
- Uzak kameraya 1.0×–4.0× dijital zoom komutu eklendi. Görüntü üzerinde iki parmakla yerel yakınlaştırma da devam eder.
- Kamera hedefi yaklaşık 640×480 JPEG, kalite 42 ve en fazla yaklaşık 11–12 FPS olacak şekilde v0.2'ye göre iyileştirildi. Ağ yetişmezse eski kareler birikmez.
- Ses 8 kHz'den 16 kHz'e çıkarıldı. Ses parçaları artık tek alanı ezmek yerine sıralı kısa parçalar halinde tutulur; bu sayede ağ dalgalanmasında kesilme riski azalır.
- Arayüz sadeleştirildi ve yeni uygulama logosu eklendi.
- Kamera/mikrofon kullanımı gizli değildir; kamera telefonunda görünür foreground bildirimi devam eder.

## İzinler

Kamera telefonunda **Kamera**, **Mikrofon** ve Android 13+ için **Bildirim** izni gerekir. Kontrol telefonunda yalnızca karşı tarafa konuşmak için mikrofon izni gerekir.

Konum izni artık istenmez ve AndroidManifest'te bulunmaz.

## Firebase

Firebase Authentication > Anonymous etkin olmalıdır. Realtime Database kuralları için `firebase_database_rules.json` kullanılabilir.

Paket adı: `com.ailemyanimda.app`

Firebase istemci bilgileri `FirebaseProvider.java` içinde mevcut projeye gömülüdür.

## GitHub Actions ile APK oluşturma

Projeyi GitHub'a yükleyip Actions sekmesindeki **Build Android APK** iş akışını çalıştırın. İş akışı debug APK'yı `AilemYanimda-debug-apk` artifact'i olarak üretir.
