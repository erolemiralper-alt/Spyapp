package com.ailemyanimda.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Size;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.google.firebase.database.DatabaseReference;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class CameraStreamer {
    // Realtime Database video icin ideal degildir. Kaliteyi v0.2'ye gore artirirken
    // gecikmenin birikmemesi icin sadece en guncel kareyi gonderiyoruz.
    private static final long FRAME_INTERVAL_MS = 85L; // hedef ~11-12 FPS
    private static final byte JPEG_QUALITY = 42;

    private final Context context;
    private final DatabaseReference frameRef;
    private HandlerThread thread;
    private Handler h;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;
    private boolean running = false;
    private String wantedLens = "back";
    private volatile boolean uploading = false;
    private int frameRotation = 90;
    private Rect activeArray;
    private float cameraMaxZoom = 1f;
    private volatile float wantedZoom = 1f;

    public CameraStreamer(Context c, DatabaseReference ref) {
        context = c.getApplicationContext();
        frameRef = ref;
    }

    public synchronized void start(String lens) {
        if (running && lens.equals(wantedLens)) return;
        stop();
        wantedLens = lens;
        running = true;
        uploading = false;
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            running = false;
            return;
        }

        thread = new HandlerThread("AilemCamera");
        thread.start();
        h = new Handler(thread.getLooper());

        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            String id = findCamera(cm, lens);
            if (id == null) { running = false; return; }

            CameraCharacteristics cc = cm.getCameraCharacteristics(id);
            Integer sensorOrientation = cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
            frameRotation = sensorOrientation == null ? 90 : sensorOrientation;
            activeArray = cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float mz = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            cameraMaxZoom = mz == null ? 1f : Math.max(1f, mz);

            android.hardware.camera2.params.StreamConfigurationMap map =
                    cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size size = chooseSize(map == null ? null : map.getOutputSizes(ImageFormat.JPEG));

            reader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(r -> {
                Image image = null;
                try {
                    image = r.acquireLatestImage();
                    if (image == null || uploading) return;
                    ByteBuffer buf = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);

                    Map<String,Object> m = new HashMap<>();
                    m.put("jpeg", Base64.encodeToString(bytes, Base64.NO_WRAP));
                    m.put("time", System.currentTimeMillis());
                    m.put("width", size.getWidth());
                    m.put("height", size.getHeight());
                    m.put("rotation", frameRotation);
                    uploading = true;
                    frameRef.setValue(m).addOnCompleteListener(t -> uploading = false);
                } finally {
                    if (image != null) image.close();
                }
            }, h);

            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(@NonNull CameraDevice c) { device = c; createSession(); }
                @Override public void onDisconnected(@NonNull CameraDevice c) { c.close(); device = null; }
                @Override public void onError(@NonNull CameraDevice c, int e) { c.close(); device = null; }
            }, h);
        } catch (Exception e) {
            stop();
        }
    }

    public void setZoom(float zoom) {
        wantedZoom = Math.max(1f, Math.min(4f, zoom));
    }

    private String findCamera(CameraManager cm, String lens) throws CameraAccessException {
        int wanted = "front".equals(lens)
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;
        String fallback = null;
        for (String id : cm.getCameraIdList()) {
            if (fallback == null) fallback = id;
            Integer f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
            if (f != null && f == wanted) return id;
        }
        return fallback;
    }

    private Size chooseSize(Size[] sizes) {
        if (sizes == null || sizes.length == 0) return new Size(640, 480);
        // 640x480'e en yakin, tercihen 640x480'i asmayan JPEG boyutu.
        Size best = null;
        long target = 640L * 480L;
        long bestDiff = Long.MAX_VALUE;
        for (Size x : sizes) {
            long area = (long) x.getWidth() * x.getHeight();
            if (area > target) continue;
            long diff = target - area;
            if (diff < bestDiff) { best = x; bestDiff = diff; }
        }
        if (best != null) return best;

        best = sizes[0];
        bestDiff = Math.abs((long)best.getWidth() * best.getHeight() - target);
        for (Size x : sizes) {
            long diff = Math.abs((long)x.getWidth() * x.getHeight() - target);
            if (diff < bestDiff) { best = x; bestDiff = diff; }
        }
        return best;
    }

    private void createSession() {
        try {
            device.createCaptureSession(Collections.singletonList(reader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(@NonNull CameraCaptureSession s) {
                            session = s;
                            if (h != null) h.post(captureLoop);
                        }
                        @Override public void onConfigureFailed(@NonNull CameraCaptureSession s) {}
                    }, h);
        } catch (Exception e) {
            stop();
        }
    }

    private Rect cropForZoom(float requested) {
        Rect a = activeArray;
        if (a == null) return null;
        float z = Math.max(1f, Math.min(Math.min(4f, cameraMaxZoom), requested));
        if (z <= 1.01f) return a;
        int cropW = Math.max(1, Math.round(a.width() / z));
        int cropH = Math.max(1, Math.round(a.height() / z));
        int left = a.centerX() - cropW / 2;
        int top = a.centerY() - cropH / 2;
        return new Rect(left, top, left + cropW, top + cropH);
    }

    private final Runnable captureLoop = new Runnable() {
        @Override public void run() {
            if (!running || device == null || session == null) return;
            try {
                CaptureRequest.Builder b = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(reader.getSurface());
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                b.set(CaptureRequest.JPEG_QUALITY, JPEG_QUALITY);
                Rect crop = cropForZoom(wantedZoom);
                if (crop != null) b.set(CaptureRequest.SCALER_CROP_REGION, crop);
                session.capture(b.build(), null, h);
            } catch (Exception ignored) {}
            if (h != null) h.postDelayed(this, FRAME_INTERVAL_MS);
        }
    };

    public synchronized void stop() {
        running = false;
        uploading = false;
        if (h != null) h.removeCallbacksAndMessages(null);
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (device != null) device.close(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        session = null;
        device = null;
        reader = null;
        activeArray = null;
        cameraMaxZoom = 1f;
        if (thread != null) { thread.quitSafely(); thread = null; }
        h = null;
    }
}
