package com.ailemyanimda.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

public class TrackingService extends Service {
    private static final String CH = "ailem_live";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private DatabaseReference base;
    private DatabaseReference infoConnected;
    private CameraStreamer camera;
    private AudioSender micSender;
    private AudioPlayer caregiverAudio;
    private String lens = "back";
    private float cameraZoom = 1f;
    private boolean cameraOn = false;
    private boolean micOn = false;
    private boolean caregiverTalking = false;
    private boolean firebaseConnected = false;
    private ValueEventListener cameraListener, lensListener, zoomListener, audioListener;
    private ValueEventListener caregiverTalkingListener, presenceListener;
    private boolean firebaseStarting = false;
    private boolean logicStarted = false;
    private long authRetryMs = 3000L;
    private final Runnable firebaseRetry = this::authenticate;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1001, notification("Bağlantı hazırlanıyor"));
        authenticate();
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (!ServiceRestartReceiver.isTracked(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!logicStarted) authenticate();
        ServiceRestartReceiver.schedule(this, 5 * 60 * 1000L);
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        ServiceRestartReceiver.schedule(this, 5_000L);
        super.onTaskRemoved(rootIntent);
    }

    @Override public android.os.IBinder onBind(Intent i) { return null; }

    private void authenticate() {
        if (logicStarted || firebaseStarting || !ServiceRestartReceiver.isTracked(this)) return;
        firebaseStarting = true;
        FirebaseAuth a = FirebaseProvider.auth(this);
        Runnable go = () -> {
            firebaseStarting = false;
            authRetryMs = 3000L;
            handler.removeCallbacks(firebaseRetry);
            startLogic();
        };
        if (a.getCurrentUser() != null) go.run();
        else a.signInAnonymously()
                .addOnSuccessListener(x -> go.run())
                .addOnFailureListener(e -> {
                    firebaseStarting = false;
                    scheduleFirebaseRetry();
                });
    }

    private void scheduleFirebaseRetry() {
        if (logicStarted || !ServiceRestartReceiver.isTracked(this)) return;
        handler.removeCallbacks(firebaseRetry);
        handler.postDelayed(firebaseRetry, authRetryMs);
        authRetryMs = Math.min(60_000L, authRetryMs * 2L);
    }

    private void startLogic() {
        if (logicStarted) return;
        String secret = AppPrefs.secret(this);
        if (secret.isEmpty()) { stopSelf(); return; }
        logicStarted = true;

        FirebaseDatabase db = FirebaseProvider.db(this);
        base = db.getReference("families").child(secret);
        infoConnected = db.getReference(".info/connected");

        // v0.3: konum, konum gecmisi, SOS ve pil verileri artik tutulmuyor.
        base.child("location").removeValue();
        base.child("history").removeValue();
        base.child("latest").removeValue();
        base.child("sos").removeValue();
        base.child("status/battery").removeValue();

        camera = new CameraStreamer(this, base.child("camera/frame"));
        micSender = new AudioSender(this, base.child("audio/fromTracked"));
        caregiverAudio = new AudioPlayer(this, base.child("audio/fromCaregiver"));

        presenceListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                firebaseConnected = Boolean.TRUE.equals(s.getValue(Boolean.class));
                if (firebaseConnected && base != null) {
                    base.child("status/online").onDisconnect().setValue(false);
                    base.child("status/disconnectedAt").onDisconnect().setValue(ServerValue.TIMESTAMP);
                    Map<String,Object> status = new HashMap<>();
                    status.put("online", true);
                    status.put("lastSeen", ServerValue.TIMESTAMP);
                    base.child("status").updateChildren(status);
                }
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        infoConnected.addValueEventListener(presenceListener);

        cameraListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                boolean requested = Boolean.TRUE.equals(s.getValue(Boolean.class));
                boolean hasPermission = ContextCompat.checkSelfPermission(TrackingService.this,
                        Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
                cameraOn = requested && hasPermission;
                if (cameraOn) {
                    camera.setZoom(cameraZoom);
                    camera.start(lens);
                } else camera.stop();
                base.child("status/cameraPermissionMissing").setValue(requested && !hasPermission);
                base.child("status/cameraActive").setValue(cameraOn);
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        lensListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                String x = s.getValue(String.class);
                if (x != null && ("front".equals(x) || "back".equals(x))) {
                    lens = x;
                    camera.stop();
                    if (cameraOn) {
                        camera.setZoom(cameraZoom);
                        camera.start(lens);
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        zoomListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Object raw = s.getValue();
                Number n = raw instanceof Number ? (Number) raw : null;
                cameraZoom = n == null ? 1f : Math.max(1f, Math.min(4f, n.floatValue()));
                if (camera != null) camera.setZoom(cameraZoom);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        audioListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                boolean wantsAudio = Boolean.TRUE.equals(s.getValue(Boolean.class));
                boolean hasPermission = ContextCompat.checkSelfPermission(TrackingService.this,
                        Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                boolean started = false;
                if (wantsAudio && hasPermission) started = micSender.start();
                else micSender.stop();
                micOn = wantsAudio && hasPermission && started;
                base.child("status/audioPermissionMissing").setValue(wantsAudio && !hasPermission);
                base.child("status/audioCaptureFailed").setValue(wantsAudio && hasPermission && !started);
                base.child("status/audioActive").setValue(micOn);
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        caregiverTalkingListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                caregiverTalking = Boolean.TRUE.equals(s.getValue(Boolean.class));
                if (caregiverTalking) caregiverAudio.start();
                else caregiverAudio.stop();
                updateForegroundState();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };

        base.child("commands/cameraEnabled").addValueEventListener(cameraListener);
        base.child("commands/lens").addValueEventListener(lensListener);
        base.child("commands/cameraZoom").addValueEventListener(zoomListener);
        base.child("commands/audioEnabled").addValueEventListener(audioListener);
        base.child("commands/caregiverTalking").addValueEventListener(caregiverTalkingListener);

        handler.post(heartbeat);
    }

    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (base != null && firebaseConnected) {
                Map<String,Object> s = new HashMap<>();
                s.put("online", true);
                s.put("lastSeen", ServerValue.TIMESTAMP);
                base.child("status").updateChildren(s);
            }
            handler.postDelayed(this, 5_000L);
        }
    };

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Ailem Yanımda",
                    NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Kamera, mikrofon ve bağlantı durumu");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification(String text) {
        Intent i = new Intent(this, TrackedActivity.class);
        PendingIntent p = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT |
                        (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        return new NotificationCompat.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Ailem Yanımda")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(p)
                .build();
    }

    private void updateForegroundState() {
        String text;
        if (!firebaseConnected) text = "Bağlantı kapalı — yeniden bağlanıyor";
        else if (cameraOn && micOn) text = "Bağlantı açık • Kamera + mikrofon açık";
        else if (cameraOn) text = "Bağlantı açık • Kamera açık";
        else if (micOn) text = "Bağlantı açık • Mikrofon açık";
        else if (caregiverTalking) text = "Bağlantı açık • Sesli konuşma";
        else text = "Bağlantı açık";
        if (caregiverTalking && (cameraOn || micOn)) text += " • Sesli konuşma";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1001, notification(text));
    }

    @Override public void onDestroy() {
        if (ServiceRestartReceiver.isTracked(this)) ServiceRestartReceiver.schedule(this, 5_000L);
        logicStarted = false;
        firebaseStarting = false;
        firebaseConnected = false;
        handler.removeCallbacksAndMessages(null);
        if (camera != null) camera.stop();
        if (micSender != null) micSender.stop();
        if (caregiverAudio != null) caregiverAudio.stop();
        if (infoConnected != null && presenceListener != null) infoConnected.removeEventListener(presenceListener);
        if (base != null) {
            base.child("status/online").setValue(false);
            base.child("status/cameraActive").setValue(false);
            base.child("status/audioActive").setValue(false);
            if (cameraListener != null) base.child("commands/cameraEnabled").removeEventListener(cameraListener);
            if (lensListener != null) base.child("commands/lens").removeEventListener(lensListener);
            if (zoomListener != null) base.child("commands/cameraZoom").removeEventListener(zoomListener);
            if (audioListener != null) base.child("commands/audioEnabled").removeEventListener(audioListener);
            if (caregiverTalkingListener != null) base.child("commands/caregiverTalking").removeEventListener(caregiverTalkingListener);
        }
        super.onDestroy();
    }
}
